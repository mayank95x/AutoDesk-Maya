Name:Mayank Bhoria
Roll NO:2015054


1.Bowling Ball

Heavy material ,thus bounces less,stops easily

2.Beach Ball

Light material,thus bounces more,stops at a distance,changes shape

3.Canvas Ball

Light material,thus bounces more but does not change shape